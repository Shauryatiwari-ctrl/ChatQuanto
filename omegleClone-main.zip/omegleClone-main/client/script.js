function generateUniqueId() {
    return '_' + Date.now() + '-' + Math.floor(Math.random() * 1000);
}

